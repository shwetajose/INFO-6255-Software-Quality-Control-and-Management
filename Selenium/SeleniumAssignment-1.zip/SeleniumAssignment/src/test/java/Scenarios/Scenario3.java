package test.java.Scenarios;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Scenario3 {
	WebDriver driver;
	Properties prop;
	
	@BeforeMethod
	public void beforeMethod() throws IOException {
		// Setting the system property for the web driver to be used
		System.setProperty("webdriver.chrome.driver", "C://Users//geeth//Downloads//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C://Users//geeth//eclipse-workspace//SeleniumAssignment//config_file//config.properties");
		prop = new Properties();
		prop.load(fis);
		driver.manage().window().maximize();
		//ExtentReports
		//FileOutputStream fos = new FileOutputStream("C:\\Users\\geeth\\eclipse-workspace\\SeleniumAssignment\\Report3.html");
		//extent = new ExtentReports("C:\\Users\\geeth\\eclipse-workspace\\SeleniumAssignment\\Report3.html", false);
		// Maximizing the newly opened browser window
		//driver.manage().window().maximize();
	}

	@AfterMethod
	public void afterMethod() {
		// Flushing and quitting the driver and the browser window
		driver.manage().deleteAllCookies();
	    driver.quit();
	}
 
	@Test
	public void scenario3() throws InterruptedException, IOException {
		//test = extent.startTest("Scenario 3", "Browse_Classes");
    	login(3);
        
    	//Keyword course is searched in the search bar
        String urlBefore = driver.getCurrentUrl();
        //Click on Resources Tab
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[2]/div/div[3]/div/div/div/div/button/i")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Resources")).click();		
		
        //driver.findElement(By.xpath("//a[contains(text(),'Resources')]")).click();
        Thread.sleep(5000);
        //Click on Search bar
        driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[2]/div[2]/div[3]/section[1]/article[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]")).sendKeys(prop.getProperty("course"));
        Thread.sleep(5000);
        driver.findElement(By.xpath("//b[contains(text(),'Course Registration')]")).click();
        Thread.sleep(10000);
        //Screenshot
        Screenshot.takeScreenshot(3, "s3 Go to Course Registration",driver);
        String s2=Screenshot.takeScreenshot(3, "s3 Go to Course Registration",driver);
        //Log checkpoint for course registration
        //test.log(LogStatus.PASS, "Search for Course Registration" ,"Searched for Course Registration");
        //Fetches the address of webpage which is in focus(Banner)
        String window = driver.getWindowHandle();
        for (String handle : driver.getWindowHandles())
        {
            window = handle;
        }
        //Driver is switching to banner
        driver.switchTo().window(window);
        Thread.sleep(4000);
        
        //Click on Browse Classes
        driver.findElement(By.xpath("//span[contains(text(),'Browse Classes')]")).click();
        Thread.sleep(4000);
        // Select Term
        driver.findElement(By.xpath("//body/main[@id='content']/div[@id='inner-center']/div[1]/div[1]/div[2]/div[1]/fieldset[1]/div[2]/div[1]/div[1]/a[1]/span[2]/b[1]")).click();
        Thread.sleep(4000);
        // Select Spring 2023 Term
        driver.findElement(By.xpath("/html[1]/body[1]/div[7]/ul[1]/li[2]")).click();
        Thread.sleep(2000);
        //Screenshot
        Screenshot.takeScreenshot(3, "scenario3 Select Term",driver);
        String s3=Screenshot.takeScreenshot(3, "scenario3 Select Term",driver);
        //Log checkpoint for Spring 2023 Semester
        //test.log(LogStatus.PASS, "Select Spring 2023 Semester" ,"Select Spring 2023 Semester");
        driver.findElement(By.id("term-go")).click();
        Thread.sleep(2000);

        //Input Requested Major
        String courseterm = driver.findElement(By.xpath("//*[@id=\"search\"]/label")).getText();
        // Hard Assertion, Checking if the term entered is summer full 2021 semester 
        Assert.assertEquals(courseterm, "Term: Spring 2023 Semester");
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/p[1]/div[1]/ul[1]/li[1]/input[1]")).sendKeys("Information Systems Program");
        Thread.sleep(2000);
        //Select Information Systems Program
        driver.findElement(By.xpath("/html[1]/body[1]/div[14]/ul[1]/li[1]")).click();
        Thread.sleep(5000);
        //Screenshot
        Screenshot.takeScreenshot(3, "s3 Selected Major",driver);
        String s6=Screenshot.takeScreenshot(3, "s3 Selected Major",driver);
        //Log checkpoint for Information Systems Major
        //test.log(LogStatus.PASS, "Select Major:Information Systems Program","Select Major:Information Systems Program");
        driver.findElement(By.id("search-go")).click();
        //Screenshot
        Screenshot.takeScreenshot(3, "s3 Result",driver);
        String s7=Screenshot.takeScreenshot(3, "s3 Result",driver);
        //test.log(LogStatus.PASS, "Able to browse courses" ,"Able to browse courses");
        Thread.sleep(2000);
       
//        String urlAfter = driver.getCurrentUrl();
//        if (!urlAfter.equals(urlBefore)) {
//            test.log(LogStatus.PASS, "Successfully Browsed Courses","Successfully Browsed Courses");
//        } else {
//            test.log(LogStatus.FAIL, "Failure Browse Course");
//        }
        
        
		String browseClasses = driver.findElement(By.xpath("/html/body/main/div[1]/div/h1")).getText();
		Set<String> expected = new HashSet<String>();
		expected.add("Browse Classes");
		
		Set<String> actual = new HashSet<String>();
		actual.add(browseClasses);
		
	    String result="Pass";
	    try{
	    	AssertJUnit.assertEquals(actual, expected);
	    	} catch(AssertionError e){
	    	result="Fail";
	    	}
	    
	    //to add to the report
	    Report.updateResultupdateResult(3, actual.toString(), 
	    		expected.toString(), result);
        //End Report and write test cases to HTML file
//        extent.endTest(test);
//        extent.flush();
	}
	
	public void login(int scenarioNumber)throws InterruptedException {
		
		//Navigate to URL
        driver.get("https://my.northeastern.edu/");
        //Screenshot
        Screenshot.takeScreenshot(scenarioNumber, "s3 Before Login", driver);
        Thread.sleep(1000);
        //Click Login button
        driver.findElements(By.xpath("//a[@href='/c/portal/login']")).get(0).click();
        Thread.sleep(1000);

        //Enter Username and Password
        driver.findElement(By.id("username")).sendKeys(prop.getProperty("id"));
        Thread.sleep(1000);
        //Screenshot
        Screenshot.takeScreenshot(scenarioNumber, "s3 Enter Username", driver);
        driver.findElement(By.id("password")).sendKeys(prop.getProperty("pwd"));
        Thread.sleep(1000);
        //Screenshot
        Screenshot.takeScreenshot(3, "s3 Enter Password",driver);

        //Login MyNEU Account
        driver.findElement(By.xpath("//button[@name='_eventId_proceed']")).click();
    	driver.switchTo().frame("duo_iframe");
    	Thread.sleep(10000);
    	//Screenshot DUO
		Screenshot.takeScreenshot(scenarioNumber, "login_duo2", driver);
		String duo2=Screenshot.takeScreenshot(scenarioNumber, "login_duo2",driver);
		//test.log(LogStatus.PASS, "View Login Page" ,"Successfully Viewed Login Page");
        Thread.sleep(10000);
        //Screenshot After Login
        Screenshot.takeScreenshot(scenarioNumber, "s3 After Login",driver);
        String s1=Screenshot.takeScreenshot(scenarioNumber, "S3 After Login",driver);
        //test.log(LogStatus.PASS, "Login Success,Enter the home page" ,"Logged in Successfully, Entered Home page");
        //Navigate to StudentHub
        String studentHubURL = "http://" + driver.findElement(By.xpath("//body[1]/div[1]/section[2]/div[1]/div[2]/div[1]/div[1]/span[1]/strong[1]")).getText() + "/";
        driver.navigate().to(studentHubURL);
        Thread.sleep(5000);
        
        //Login using Active Directory
        driver.findElement(By.xpath("//body/div[@id='fullPage']/div[@id='contentWrapper']/div[@id='content']/div[@id='workArea']/div[@id='hrdArea']/form[@id='hrd']/div[@id='bySelection']/div[3]/div[1]")).click();
        Thread.sleep(1000);
        
        //Enter email address
        driver.findElement(By.xpath("//input[@id='userNameInput']")).sendKeys(prop.getProperty("email"));
        Thread.sleep(1000);
        Screenshot.takeScreenshot(scenarioNumber, "s3 Enter Email", driver);
        
        //Enter password
        driver.findElement(By.xpath("//input[@id='passwordInput']")).sendKeys(prop.getProperty("pass"));
        Thread.sleep(5000);
        Screenshot.takeScreenshot(scenarioNumber, "s3 Enter Password-2", driver);
        
        driver.findElement(By.xpath("//span[@id='submitButton']")).click();
        Thread.sleep(10000);	
    	driver.findElement(By.xpath("//input[@id='idSIButton9']")).click();
    	Thread.sleep(10000);
    	driver.findElement(By.xpath("//body/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/button[1]/span[1]")).click();
    	Thread.sleep(10000);	
	}

}
