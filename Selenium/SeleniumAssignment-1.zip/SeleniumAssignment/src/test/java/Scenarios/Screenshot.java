package test.java.Scenarios;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
	  public static String takeScreenshot(int scenarioNumber, String screenshotName, WebDriver driver) {
	        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        try {
	            String path = "C://Users//geeth//eclipse-workspace//SeleniumAssignment//Screenshots//Scenario-" + Integer.toString(scenarioNumber);
	            File file = new File(path);
	            if(!file.exists())
	            	file.mkdir();
	            path = path + "\\"+ screenshotName + ".png";
	            FileUtils.copyFile(scrFile, new File(path));
	            return path;
	        }
	        catch (IOException e) {
	            e.printStackTrace();
	            return e.getMessage();
	        }
	    }
}
