package test.java.Scenarios;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Scenario1 {
	
	WebDriver driver;
	Properties prop;
	
	@BeforeMethod
	public void beforeMethod() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C://Users//geeth//Downloads//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C://Users//geeth//eclipse-workspace//SeleniumAssignment//config_file//config.properties");
		prop = new Properties();
		prop.load(fis);
		driver.manage().window().maximize();
		
		//FileOutputStream fos = new FileOutputStream("C:\\Users\\geeth\\eclipse-workspace\\SeleniumAssignment\\Report1.html");
		//extent = new ExtentReports("C:\\Users\\geeth\\eclipse-workspace\\SeleniumAssignment\\Report1.html", false);
	}

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}

    public void login() throws InterruptedException {
		
			// Loading to the myNortheastern website
			driver.get("https://me.northeastern.edu");
			Screenshot.takeScreenshot(1, "My Northeastern Website", driver);
			// Click on the 'Go To Login' button
			driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[2]/div/form/div[1]/div[2]/div/span")).click();
			//driver.findElement(By.xpath("//a[normalize-space()='Go To Login']")).click();
			Screenshot.takeScreenshot(1, "My Northeastern - Go to Login", driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Fetch the username and enter it in the text field
			driver.findElement(By.xpath("//input[@id='username']")).sendKeys(prop.getProperty("id"));
			Screenshot.takeScreenshot(1, "Enter Username", driver);
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			// Fetch the password and enter it in the password field
		    driver.findElement(By.xpath("//input[@id='password']")).sendKeys(prop.getProperty("pwd"));
		    Screenshot.takeScreenshot(1, "Enter Password", driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//test.log(LogStatus.PASS, "Enter username and password" ,"Username and password entered.");
			// Click on the Log In button
		    driver.findElement(By.xpath("//button[normalize-space()='Log In']")).click();
		    Thread.sleep(10000);
		    //test.log(LogStatus.PASS, "Click Log In" ,"Login button clicked");
		    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		   ///////
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();
		    
		    //Click on "let's go"
		    Thread.sleep(10000);
		    Screenshot.takeScreenshot(1, "My Northeastern Portal", driver);
		    driver.findElement(By.xpath("//*[@id=\"id__81\"]")).click();
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    //////
		    Thread.sleep(10000);
		    Screenshot.takeScreenshot(1, "Student Hub Portal", driver);
			
		   
	}

	@Test
	public void scenario1() throws InterruptedException, IOException {
		//test = extent.startTest("Scenario 1", "Adding_My_Favorites");
		// Login to the StudentHub portal
		login();
		//click on 3 dots and resources
		//test.log(LogStatus.PASS, "Login" ,"Login Successful");
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[2]/div/div[3]/div/div/div/div/button/i")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Resources")).click();		
		Thread.sleep(5000);
		// Click on the Academics, Classes & Registration Section to fetch sublinks
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[1]/div[2]/div/div[1]/div/p")).click();
		Thread.sleep(5000);
		
		//Add items to my favorites
		//Click course catalog
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[9]/div/i")).click();
		//click course registration
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[11]/div/i")).click();
		//test.log(LogStatus.PASS, "Add items to My Favorites" ,"Added items to My Favorites successfully");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		Screenshot.takeScreenshot(1, "Favorites", driver);
		
		Thread.sleep(1000);
		
		// Retrieving a string for assertion
		String firstFavStr = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[2]/div[2]/div/div/div[1]/div/a")).getText();
		String secondFavStr = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/a")).getText();
		//System.out.println(courseCatalog + courseRegistration);
		// System.out.println(str + "   +++");
		Set<String> expected = new HashSet<String>();
		expected.add("Course Registration");
		expected.add("Course Catalog");
		
		Set<String> actual = new HashSet<String>();
		actual.add(firstFavStr);
		actual.add(secondFavStr);
		
	    String result="Pass";
	    try{
	    	AssertJUnit.assertEquals(actual, expected);
	    	//test.log(LogStatus.PASS, "Checking if items are added to My Favorites" ,"Verified that the items are added to My Favorites.");
//			    	Assert.assertNotNull(courseCatalog); //to check if it is correct
	    } catch(AssertionError e){
	    	result="Fail";
	    	//test.log(LogStatus.FAIL, "Checking if items are added to My Favorites" ,"Items not in My Favorites.");
	    }
	    
	    //to add to the report
	    Report.updateResultupdateResult(1, actual.toString(), 
	    		expected.toString(), result);
		
	    //extent.endTest(test);
        //extent.flush();
	}

}
