package test.java.Scenarios;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class Report {
	public static void updateResultupdateResult(int scenarioNo, String actualResult,String expectedResult,String result) throws IOException {
		
		//getting the date and time
		String startDateTime = new SimpleDateFormat("MM-dd-yyyy_HH-ss").format(new GregorianCalendar().getTime());

		//checking if its the first case
	    int firstCase = 0;
	    
	    //getting the directory location
		String userDirector = System.getProperty("user.dir");

		//saving the test report to the location
		String resultFile = userDirector + "/TestReport.html";
		
		//making the object of the file
		File file = new File(resultFile);

		//condition to check if file does not exist, then create the file
		if (!file.exists()) {
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fw);
			
			//creating an html document with the title
			bw.write("<html>" + "\n");
			bw.write("<head><title>" + "HTML Test Report" + "</title>" + "\n");
			bw.write("</head>" + "\n");
			bw.write("<body>");
			bw.write("<font face='Tahoma'size='2'>" + "\n");
			bw.write("<u><h1 align='center'>" + "HTML Test Report" + "</h1></u>" + "\n");
			bw.flush();
			bw.close();
			firstCase=1;
		}
		
		//to write the result
		BufferedWriter bw1 = new BufferedWriter(new FileWriter(file, true));
		
		//In case of the first result,create the column headers
		if (firstCase == 1) {
			
			//html code to create a table with 4 columns
			bw1.write("<table align='center' border='0' width='70%' height='10'>");
			bw1.write("<tr><td width='70%' </td></tr>");
			bw1.write("<table align='center' border='1' width='70%' height='47'>");
			bw1.write("<tr>");
			bw1.write("<td colspan='1' align='center'><b><font color='#000000' face='Tahoma' size='2'>Group 3 :&nbsp;&nbsp;&nbsp;</font><font color='#0000FF'' face='Tahoma' size='2'>Selenium Automation Assignment </font></b></td>");
			bw1.write("<td colspan='2' align='left'><b><font color='#000000' face='Tahoma' size='2'>Start Time :&nbsp;</font></b><font color='#0000FF'' face='Tahoma' size='1'>" + startDateTime + " </font></td>");
			bw1.write("</tr>");
			bw1.write("</tr>");
			
			//column1
			bw1.write("<td  bgcolor='#CCCCFF' align='left'><b><font color='#000000' face='Tahoma' size='2'>Test scenario name</font></b></td>");
			//column2
			bw1.write("<td  bgcolor='#CCCCFF' align='left'><b><font color='#000000' face='Tahoma' size='2'>Actual</font></b></td>");
			//column3
			bw1.write("<td  bgcolor='#CCCCFF' align='center'><b><font color='#000000' face='Tahoma' size='2'>Expected </font></b></td>");
			//column4
			bw1.write("<td  bgcolor='#CCCCFF' align='center'><b><font color='#000000' face='Tahoma' size='2'>Pass/Fail </font></b></td>");
			bw1.write("</tr>");
		}
		
		//add the data to the columns of a row
		bw1.write("<tr>" + "\n");
		bw1.write("<td bgcolor='#FFFFDC'align='Center'><font color='#000000' face='Tahoma' size='2'>" + "Scenario No."+scenarioNo + "</font></td>" + "\n");
		bw1.write("<td  bgcolor='#FFFFDC' valign='middle' align='left'><b><font color='#000000' face='Tahoma' size='2'>" + actualResult + "</font></b></td>" + "\n");
		bw1.write("<td  bgcolor='#FFFFDC' valign='middle' align='left'><b><font color='#000000' face='Tahoma' size='2'>" + expectedResult + "</font></b></td>" + "\n");
		bw1.write("<td  bgcolor='#FFFFDC' valign='middle' align='left'><b><font color='#000000' face='Tahoma' size='2'>" + result + "</font></b></td>" + "\n");
		bw1.write("</tr>" + "\n");
		bw1.write("</body>" + "\n");
		bw1.write("</html>");
		bw1.flush();
		bw1.close();
	}
}
