package test.java.Scenarios;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Scenario2 {
	
	WebDriver driver;
	Properties prop;
	
	@BeforeMethod
	public void beforeMethod() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C://Users//geeth//Downloads//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C://Users//geeth//eclipse-workspace//SeleniumAssignment//config_file//config.properties");
		prop = new Properties();
		prop.load(fis);
		driver.manage().window().maximize();
		
		//FileOutputStream fos = new FileOutputStream("C:\\Users\\geeth\\eclipse-workspace\\SeleniumAssignment\\Report2.html");
		//extent = new ExtentReports("C:\\Users\\geeth\\eclipse-workspace\\SeleniumAssignment\\Report2.html", false);
	}

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}

    public void login() throws InterruptedException {
		
			// Loading to the myNortheastern website
			driver.get("https://me.northeastern.edu");
			Screenshot.takeScreenshot(2, "My Northeastern Website", driver);
			// Click on the 'Go To Login' button
			driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[2]/div/form/div[1]/div[2]/div/span")).click();
			//driver.findElement(By.xpath("//a[normalize-space()='Go To Login']")).click();
			Screenshot.takeScreenshot(2, "My Northeastern - Go to Login", driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Fetch the username and enter it in the text field
			driver.findElement(By.xpath("//input[@id='username']")).sendKeys(prop.getProperty("id"));
			Screenshot.takeScreenshot(2, "Enter Username", driver);
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			// Fetch the password and enter it in the password field
		    driver.findElement(By.xpath("//input[@id='password']")).sendKeys(prop.getProperty("pwd"));
		    Screenshot.takeScreenshot(2, "Enter Password", driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Click on the Log In button
		    driver.findElement(By.xpath("//button[normalize-space()='Log In']")).click();
		    Thread.sleep(10000);
		    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		   
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    //Click on "let's go"
		    Thread.sleep(10000);
		    Screenshot.takeScreenshot(2, "My Northeastern Portal", driver);
		    driver.findElement(By.xpath("//*[@id=\"id__81\"]")).click();
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  
		    Thread.sleep(10000);
		    Screenshot.takeScreenshot(2, "Student Hub Portal", driver);
			
		    //driver.switchTo().window(originalWindow);
		    
	}

	@Test
	public void scenario2() throws InterruptedException, IOException {
		//test = extent.startTest("Scenario 2", "Deleting_Favorites");
		// Login to the StudentHub portal
		login();
		//click on 3 dots and resources
		//test.log(LogStatus.PASS, "Login" ,"Login Successful");
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[2]/div/div[3]/div/div/div/div/button/i")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Resources")).click();		
		Thread.sleep(5000);
		// Click on the Academics, Classes & Registration Section to fetch sublinks
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[1]/div[2]/div/div[1]/div/p")).click();
		Thread.sleep(3000);
		//Scroll down
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-350)", "");
		//Take screenshots of favorites
		Screenshot.takeScreenshot(2, "Favorites", driver);
		
		//Delete favorites
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[9]/div/i")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[11]/div/i")).click();
		Thread.sleep(1000);
		//Take screenshots of deleted favorites
		Screenshot.takeScreenshot(2, "Deleted favorites", driver);
		
		//test.log(LogStatus.PASS, "Deleting My Favorites" ,"Deleted Successfully");
		// Retrieving a string for assertion
		String emptyCheck = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[2]/div[2]/div/div/p[1]")).getText();
		emptyCheck = emptyCheck.substring(0, 7) + emptyCheck.substring(8, emptyCheck.length());
		Set<String> expected = new HashSet<String>();
		expected.add("You dont have any links here yet.");
		
		Set<String> actual = new HashSet<String>();
		actual.add(emptyCheck);
		
	    String result="Pass";
	    try{
	    	AssertJUnit.assertEquals(actual, expected);
	    } catch(AssertionError e){
	    	result="Fail";
	    }
	    
	    //to add to the report
	    Report.updateResultupdateResult(2, actual.toString(), 
	    		expected.toString(), result);
//	    extent.endTest(test);
//        extent.flush();
	}

}
