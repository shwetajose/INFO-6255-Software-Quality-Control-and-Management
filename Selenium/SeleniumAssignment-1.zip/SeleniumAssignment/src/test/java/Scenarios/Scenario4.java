package test.java.Scenarios;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;


public class Scenario4 {
	WebDriver driver;
	Properties prop;
	
	@BeforeMethod
	public void beforeMethod() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C://Users//geeth//Downloads//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C://Users//geeth//eclipse-workspace//SeleniumAssignment//config_file//config.properties");
		prop = new Properties();
		prop.load(fis);
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}
	
	public void login() throws InterruptedException {
		
		// Loading to the myNortheastern website
		driver.get("https://my.northeastern.edu");
		Screenshot.takeScreenshot(4, "My Northeastern Website", driver);
		// Click on the 'Go To Login' button
		driver.findElement(By.xpath("//a[normalize-space()='Go To Login']")).click();
		Screenshot.takeScreenshot(4, "My Northeastern - Go to Login", driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Fetch the username and enter it in the text field
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(prop.getProperty("id"));
		Screenshot.takeScreenshot(4, "Enter Username", driver);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Fetch the password and enter it in the password field
	    driver.findElement(By.xpath("//input[@id='password']")).sendKeys(prop.getProperty("pwd"));
	    Screenshot.takeScreenshot(4, "Enter Password", driver);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Click on the Log In button
	    driver.findElement(By.xpath("//button[normalize-space()='Log In']")).click();
	    
	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		// Click on Launch the Hub Now button
		Screenshot.takeScreenshot(4, "My Northeastern Portal", driver);
		
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Launch the Hub Now >")));
		element.click();
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		// Switch to the newly opened StudentHub tab
	    String originalWindow = driver.getWindowHandle();
	    for(String s: driver.getWindowHandles()) {
	    	if(originalWindow != s)
	    		originalWindow = s;
	    };
	    Screenshot.takeScreenshot(4, "Student Hub Portal", driver);
		
	    driver.switchTo().window(originalWindow);
	    Thread.sleep(5000);
		//Thread.sleep(8000);
}

	@Test
	public void scenario4() throws InterruptedException, IOException{
//		test = extent.startTest("Scenario 4", "Add_Items_To_Cart");
				//login
			    //login();
		driver.get("https://sso.bncollege.com/bes-oid/oauth/login?goto=%2Foauth%2Fauthorize%3Fclient_id%3Dnortheastern-fan%26redirect_uri%3Dhttps%253A%252F%252Fnortheastern.spirit.bncollege.com%252Fapi%252Faccount%252Foauth-v2%252Foidcreturn%26state%3DeyJzZXNzaW9uSWQiOiIwZDQ5MTYzMC02NzU4LTExZWQtOWE4Yi1iM2EwYjcxY2ZjMmQiLCJuZXh0UGF0aG5hbWUiOiIvYWNjb3VudCJ9%26response_type%3Dcode%26scope%3Dopenid%2520profile%26display%3Dpage%26book_store_site%3Dnortheastern.bncollege.com");
		Screenshot.takeScreenshot(4, "Website", driver);
	    Thread.sleep(5000);

	    //driver.findElement(By.xpath("//*[@id=\"bnedLoginButton\"]")).click();
	    //login
	    Thread.sleep(5000);
	    driver.findElement(By.id("email")).sendKeys(prop.getProperty("email"));
	    driver.findElement(By.id("password")).sendKeys(prop.getProperty("pwd"));
	    driver.findElement(By.className("btn")).click();
	    Thread.sleep(3000);
	    //Screenshot after login
	    Screenshot.takeScreenshot(4, "After login", driver);
//	    test.log(LogStatus.PASS, "Login" ,"Login Successful");
	    WebElement searchElement = driver.findElement(By.id("typeahead-input-desktop"));
		Thread.sleep(1000);
		searchElement.sendKeys("sweater");
		
		Thread.sleep(2000);
		//click on search
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/header/div[3]/div[2]/div/button/i")).click();
		//After searching
		Screenshot.takeScreenshot(4, "Search", driver);
//		test.log(LogStatus.PASS, "Searching for items" ,"Search Successful");
		//d.findElement(By.xpath("//*[@id=\'foo1\']/li/a[1]/img")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[8]/div[2]/div[3]/div/div[2]/div/div/div[1]/div[1]/div/a/img")).click();
		
		Thread.sleep(4000);
		// add to cart
		driver.findElement(By.xpath("/html/body/div[2]/div/div[6]/div[2]/div[19]/div/div/div[6]/div/div[2]/div/div/div/button/span")).click();
		Thread.sleep(2000);
		//After adding to cart
		Screenshot.takeScreenshot(4, "Cart", driver);
//		test.log(LogStatus.PASS, "Adding to cart" ,"Added Successfully");
		String sweaterStr = driver.findElement(By.xpath("//*[contains(text(),'Northeastern Univ. CC039 Elliot the Bear w Sweater Plush')]")).getText();
		Thread.sleep(2000);

		Set<String> expected = new HashSet<String>();
		expected.add("Northeastern Univ. CC039 Elliot the Bear w Sweater Plush");
		
		Set<String> actual = new HashSet<String>();
		actual.add(sweaterStr);
		
	    String result="Pass";
	    try{
	    	AssertJUnit.assertEquals(actual, expected);
//	    	Assert.assertNotNull(courseCatalog); //to check if it is correct
	    } catch(AssertionError e){
	    	result="Fail";
	    }
	    
	    //to add to the report
	    Report.updateResultupdateResult(4, actual.toString(), expected.toString(), result);
		
//	    extent.endTest(test);
//        extent.flush();
		
//			    Screenshot.takeScreenshot(4, "Before_cart_checkout", driver);
//			    WebElement findElement = driver.findElement(By.xpath("//a[@class='btn btn-secondary btn-block mini-cart-checkout-button']"));
//			    findElement.click();
//			    Screenshot.takeScreenshot(4, "After_cart_checkout", driver);
//			    
//			    //Checking if the cart is empty or not
//			    String result="Pass";
//			    try{
//			    	AssertJUnit.assertNotNull(findElement);
//		    	} catch(AssertionError e){
//		    		result="Fail";
//		    	}
//			  //to add to the report
//			  boolean isnull =  findElement != null;
//			  Report.updateResultupdateResult(4,  "Cart should not empty", "Cart not Empty - " + String.valueOf(isnull), result);

	}

}




///////OTHER URL/////




//package test.java.Scenarios;
//
//import org.testng.annotations.Test;
//import org.testng.AssertJUnit;
//import org.testng.annotations.Test;
//import org.testng.annotations.BeforeTest;
//
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.time.Duration;
//import java.util.HashSet;
//import java.util.Properties;
//import java.util.Set;
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Assert;
//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeMethod;
//
//public class Scenario4 {
//	WebDriver driver;
//	Properties prop;
//	
//	@BeforeMethod
//	public void beforeMethod() throws IOException {
//		System.setProperty("webdriver.chrome.driver", "C://Users//geeth//Downloads//chromedriver_win32//chromedriver.exe");
//		driver = new ChromeDriver();
//		FileInputStream fis = new FileInputStream("C://Users//geeth//eclipse-workspace//SeleniumAssignment//config_file//config.properties");
//		prop = new Properties();
//		prop.load(fis);
//		driver.manage().window().maximize();
//	}
//
////	@AfterMethod
////	public void afterMethod() {
////		driver.quit();
////	}
//	
//	public void login() throws InterruptedException {
//		
//		// Loading to the myNortheastern website
//		driver.get("https://my.northeastern.edu");
//		Screenshot.takeScreenshot(4, "My Northeastern Website", driver);
//		// Click on the 'Go To Login' button
//		driver.findElement(By.xpath("//a[normalize-space()='Go To Login']")).click();
//		Screenshot.takeScreenshot(4, "My Northeastern - Go to Login", driver);
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		// Fetch the username and enter it in the text field
//		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(prop.getProperty("id"));
//		Screenshot.takeScreenshot(4, "Enter Username", driver);
//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//		// Fetch the password and enter it in the password field
//	    driver.findElement(By.xpath("//input[@id='password']")).sendKeys(prop.getProperty("pwd"));
//	    Screenshot.takeScreenshot(4, "Enter Password", driver);
//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//		// Click on the Log In button
//	    driver.findElement(By.xpath("//button[normalize-space()='Log In']")).click();
//	    
//	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//		// Click on Launch the Hub Now button
//		Screenshot.takeScreenshot(4, "My Northeastern Portal", driver);
//		
//	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Launch the Hub Now >")));
//		element.click();
//	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//
//		// Switch to the newly opened StudentHub tab
//	    String originalWindow = driver.getWindowHandle();
//	    for(String s: driver.getWindowHandles()) {
//	    	if(originalWindow != s)
//	    		originalWindow = s;
//	    };
//	    Screenshot.takeScreenshot(4, "Student Hub Portal", driver);
//		
//	    driver.switchTo().window(originalWindow);
//	    Thread.sleep(5000);
//}
//
//	@Test
//	public void scenario4() throws InterruptedException, IOException{
//		
//		//driver.get("https://sso.bncollege.com/bes-oid/oauth/login?goto=%2Foauth%2Fauthorize%3Fclient_id%3Dnortheastern-fan%26redirect_uri%3Dhttps%253A%252F%252Fnortheastern.spirit.bncollege.com%252Fapi%252Faccount%252Foauth-v2%252Foidcreturn%26state%3DeyJzZXNzaW9uSWQiOiIwZDQ5MTYzMC02NzU4LTExZWQtOWE4Yi1iM2EwYjcxY2ZjMmQiLCJuZXh0UGF0aG5hbWUiOiIvYWNjb3VudCJ9%26response_type%3Dcode%26scope%3Dopenid%2520profile%26display%3Dpage%26book_store_site%3Dnortheastern.bncollege.com");
//		driver.get("https://northeastern.bncollege.com/");
//		Screenshot.takeScreenshot(4, "Website", driver);
//	    Thread.sleep(5000);
//
//	    driver.findElement(By.xpath("//*[@id=\"bnedLoginButton\"]")).click();
//	    //login
//	    Thread.sleep(5000);
//	    //driver.findElement(By.xpath("//*[@id=\"courses\"]/div/div[2]/button[1]/a")).click();
//	    driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(prop.getProperty("email"));
//
//	    driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(prop.getProperty("pwd"));
//	    driver.findElement(By.xpath("//*[@id=\"submitLoginHeaderForm\"]")).click();
//	    Thread.sleep(3000);
//	    //Screenshot after login
//	    Screenshot.takeScreenshot(4, "After login", driver);
//	    WebElement searchElement = driver.findElement(By.id("typeahead-input-desktop"));
//		Thread.sleep(1000);
//		searchElement.sendKeys("sweater");
//		
//		Thread.sleep(2000);
//		//click on search
//		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/header/div[3]/div[2]/div/button/i")).click();
//		//After searching
//		Screenshot.takeScreenshot(4, "Search", driver);
//		//d.findElement(By.xpath("//*[@id=\'foo1\']/li/a[1]/img")).click();
//		driver.findElement(By.xpath("/html/body/div[2]/div/div[8]/div[2]/div[3]/div/div[2]/div/div/div[1]/div[1]/div/a/img")).click();
//		
//		Thread.sleep(4000);
//		// add to cart
//		driver.findElement(By.xpath("/html/body/div[2]/div/div[6]/div[2]/div[19]/div/div/div[6]/div/div[2]/div/div/div/button/span")).click();
//		Thread.sleep(2000);
//		//After adding to cart
//		Screenshot.takeScreenshot(4, "Cart", driver);
//		String sweaterStr = driver.findElement(By.xpath("//*[contains(text(),'Northeastern Univ. CC039 Elliot the Bear w Sweater Plush')]")).getText();
//		Thread.sleep(2000);
//		System.out.println(sweaterStr);
//		Set<String> expected = new HashSet<String>();
//		expected.add("Northeastern Univ. CC039 Elliot the Bear w Sweater Plush");
//		
//		Set<String> actual = new HashSet<String>();
//		actual.add(sweaterStr);
//		
//	    String result="Pass";
//	    try{
//	    	AssertJUnit.assertEquals(actual, expected);
////	    	Assert.assertNotNull(courseCatalog); //to check if it is correct
//	    } catch(AssertionError e){
//	    	result="Fail";
//	    }
//	    
//	    //to add to the report
//	    Report.updateResultupdateResult(4, actual.toString(), expected.toString(), result);
//		
//		
//		
////		Thread.sleep(3000);
////		// view cart
////		driver.findElement(By.xpath("/html/body/div[5]/div[3]/div/button[2]/span")).click();
////		Thread.sleep(2000);
////
