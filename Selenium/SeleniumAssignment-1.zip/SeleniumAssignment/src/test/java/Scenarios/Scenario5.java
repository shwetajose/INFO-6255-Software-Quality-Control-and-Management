package test.java.Scenarios;

import org.testng.annotations.Test;

import test.java.Scenarios.Report;
import test.java.Scenarios.Screenshot;

import org.testng.annotations.BeforeMethod;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;


public class Scenario5 {
	WebDriver driver;
	Properties prop;
	
	@BeforeMethod
	public void beforeMethod() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C://Users//geeth//Downloads//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C://Users//geeth//eclipse-workspace//SeleniumAssignment//config_file//config.properties");
		prop = new Properties();
		prop.load(fis);
		driver.manage().window().maximize();
		
	}

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}

    public void login() throws InterruptedException {
		
			// Loading to the myNortheastern website
			driver.get("https://me.northeastern.edu");
			Screenshot.takeScreenshot(1, "My Northeastern Website", driver);
			// Click on the 'Go To Login' button
			driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[2]/div/form/div[1]/div[2]/div/span")).click();
			//driver.findElement(By.xpath("//a[normalize-space()='Go To Login']")).click();
			Screenshot.takeScreenshot(1, "My Northeastern - Go to Login", driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Fetch the username and enter it in the text field
			driver.findElement(By.xpath("//input[@id='username']")).sendKeys(prop.getProperty("id"));
			Screenshot.takeScreenshot(1, "Enter Username", driver);
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			// Fetch the password and enter it in the password field
		    driver.findElement(By.xpath("//input[@id='password']")).sendKeys(prop.getProperty("pwd"));
		    Screenshot.takeScreenshot(1, "Enter Password", driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Click on the Log In button
		    driver.findElement(By.xpath("//button[normalize-space()='Log In']")).click();
		    
		    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		    Thread.sleep(5000);
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();
		    
		    //Click on "let's go"
		    Thread.sleep(5000);
		    Screenshot.takeScreenshot(1, "My Northeastern Portal", driver);
		    driver.findElement(By.xpath("//*[@id=\"id__81\"]")).click();
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    //////
		    Thread.sleep(5000);
		    Screenshot.takeScreenshot(1, "Student Hub Portal", driver);
			
		    //driver.switchTo().window(originalWindow);
		   
	}
    @Test
	public void scenario5() throws InterruptedException, IOException {
		// Login to the StudentHub portal
		login();
		//click on 3 dots and resources
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[2]/div/div[3]/div/div/div/div/button/i")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Resources")).click();		
		Thread.sleep(5000);
		Screenshot.takeScreenshot(5, "Resources", driver);
		// Click on the Academics, Classes & Registration Section to fetch sublinks
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[1]/div[2]/div/div[1]/div/p")).click();
		Thread.sleep(5000);

		//Select course registration
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/section/article/div[1]/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div[11]/div/div/a")).click();
		Thread.sleep(5000);
		String handle = driver.getWindowHandle();
		handle = driver.getWindowHandle();

		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		for (String handles : driver.getWindowHandles()) {
			if (handles.equals(handle))
				continue;
			driver.switchTo().window(handles);
		}
		//After selecting course registration
		Screenshot.takeScreenshot(5, "Course registration", driver);
		//Select plan ahead
		driver.findElement(By.xpath("/html/body/main/div[2]/div[2]/div/div/ul/li[3]/a/span[1]")).click();
		Thread.sleep(3000);
		Screenshot.takeScreenshot(5, "Plan ahead", driver);
		//click on term dropdown
		driver.findElement(By.className("select2-arrow")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("202330")).click();
	    Thread.sleep(1000);
	    // test.log(LogStatus.PASS, "Select term" ,"Term selected Successfully");
	    //Screenshot after selecting the term
		Screenshot.takeScreenshot(5,"SelectTermAfter",driver);
		
		//Clicking on Continue button
		driver.findElement(By.id("term-go")).click();
		Thread.sleep(3000);

		//Screenshot before creating a new plan button
		Screenshot.takeScreenshot(5,"CreatePlanBefore",driver);
		
		//Clicking on Create a New Plan button
		WebElement createPlanButton = driver.findElement(By.id("createPlan"));
//		
//	    String result2="Pass";
//	    try{
//	    	AssertJUnit.assertNotNull(createPlanButton);
//	    	} catch(AssertionError e){
//	    		result2="Fail";
//	    	}
//	    
//	    //to add to the report
//	    Report.updateResultupdateResult(5, createPlanButton.toString(), "NOT NULL", result2);
//		
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("createPlan")))).click();
		Thread.sleep(1000);
		
		//Take screenshot after clicking create new plan button
		Screenshot.takeScreenshot(5,"CreateNewPlanAfter",driver);
		
		//Typing a subject in subject text box to filter the results
		driver.findElement(By.id("s2id_autogen1")).sendKeys(prop.getProperty("search_filter"));
		Thread.sleep(10000);
		
		//Selecting the subject from dropdown
		driver.findElement(By.xpath("//div[@id=\"INFO\"]")).click();
		Thread.sleep(2000);
		//Take screenshot after adding the filter
		Screenshot.takeScreenshot(5,"AddFilterAfter",driver);
		
		//Clicking Search button
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("search-go")))).click();
		Thread.sleep(1000);
		
		//Take screenshot before selecting the course
		Screenshot.takeScreenshot(5,"SelectCourseBefore",driver);
		
		//Adding one course
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='table1']/tbody/tr[4]/td[6]/div/button[2]"))).click();
		Thread.sleep(1000);
		
		//Adding second course
		driver.findElement(By.xpath("//*[@id='table1']/tbody/tr[5]/td[6]/div/button[2]")).click();
		Thread.sleep(1000);
		
		//Take screenshot after selecting the course
		Screenshot.takeScreenshot(5,"SelectCourseAfter",driver);
		
		//Clicking Save Plan button
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("saveButton")))).click();
		Thread.sleep(1000);
		
		//Screenshot before adding plan name
		Screenshot.takeScreenshot(5,"AddPlanNameBefore",driver);
		
		//Enter Plan name
		driver.findElement(By.id("txt_planDesc")).sendKeys(prop.getProperty("plan_name"));
		Thread.sleep(1000);
		
		//Screenshot after adding plan name
		Screenshot.takeScreenshot(5,"AddPlanNameAfter",driver);
		
		//Click Save button
		driver.findElement(By.xpath("//div[@class=\"ui-dialog-buttonset\"]/button[2]")).click();
		
		//Take screenshot of saved plan
		Screenshot.takeScreenshot(5,"PlanSaved",driver);
		Thread.sleep(3000);
		//select plan
		driver.findElement(By.xpath("/html/body/nav/div[2]/a[4]")).click();
		
		// test.log(LogStatus.PASS, "Create a plan" ,"Plan created Successfully");
		String planCreated = driver.findElement(By.xpath("/html/body/main/div[2]/div[5]/div/div/div/div[1]/div[3]/div[2]/div[1]/span[2]")).getText();
		Set<String> expected = new HashSet<String>();
		expected.add("Group 3");
		
		Set<String> actual = new HashSet<String>();
		actual.add(planCreated);
	    String result3="Pass";
	    try{
	    	AssertJUnit.assertEquals(actual, expected);
	    	} catch(AssertionError e){
	    		result3="Fail";
	    	}
	    
	    //to add to the report
	    Report.updateResultupdateResult(5, actual.toString(), 
	    		expected.toString(), result3);
		
	    // extent.endTest(test);
        // extent.flush();		
	}

}
